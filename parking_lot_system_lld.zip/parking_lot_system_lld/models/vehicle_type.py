from enum import Enum

class VehicleType(Enum):
    Car = 1
    MotorCycle = 2
    Truck = 3