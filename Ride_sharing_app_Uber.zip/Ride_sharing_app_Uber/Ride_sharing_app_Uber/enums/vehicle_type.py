from enum import Enum

class VehicleType(Enum):
    SEDAN = "sedan"
    SUV = "suv"
    MINI = "mini"
    