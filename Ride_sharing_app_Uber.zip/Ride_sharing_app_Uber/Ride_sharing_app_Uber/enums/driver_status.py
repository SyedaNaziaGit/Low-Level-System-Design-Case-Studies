from enum import Enum

class DriverStatus(Enum):
    AVAILABLE = "available"
    BUSY = "busy"