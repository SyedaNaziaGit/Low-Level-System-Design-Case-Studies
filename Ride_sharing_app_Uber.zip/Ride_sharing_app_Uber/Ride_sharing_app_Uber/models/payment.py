class Payment:
    def __init__(self,id,ride,amount,status):
        self.id = id
        self.ride = ride
        self.amount = amount
        self.status = status