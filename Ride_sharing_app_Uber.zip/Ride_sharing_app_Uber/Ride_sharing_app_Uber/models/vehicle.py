
class Vehicle:
    def __init__(self, vehicle_id,license_plate, vehicle_type):
        self.vehicle_id = vehicle_id
        self.license_plate = license_plate
        self.vehicle_type = vehicle_type
        